$(document).ready(function (){
  /*
   * Function for validate Add Ticket form.
   * 
   */

  //-----Use data Tables for pagination,sorting and order by-----
  
    $('#ticketTable').DataTable();

  //-----For client side validation------

  $("#addTicketForm").validate({   
    rules: {
      assignee_id : {required: true },
      issue_type: {required: true,},
      issue_commented: {required: true}
    },
    messages: {
      assignee_id: "Please select your assignee.",
      issue_type:  "Please select your issue type",
      issue_commented:  "Please enter your related issue"
      }
    }); 
  $("LoginForm").validate({
    rules: {
      email: {required: true },
      password: {required: true,},     
    },
    messages: {
      assignee_id: "Please enter an EmailID.",
      password:  "Enter password",     
    }
  })

});