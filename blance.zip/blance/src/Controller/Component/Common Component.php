<?php
namespace App\Controller\Component;
use Cake\Core\Configure;
use Cake\Controller\Component;
use Cake\Mailer\Email;
use Cake\Network\Http\Client;
use Cake\ORM\TableRegistry;
class CommonComponent extends Component{

    public function sendEmail($mails,$emailContent,$template_name)
    {
        $email = new Email('default');
           $mail= $email
                ->setFrom(['tqminternal@gmail.com' => 'XYZ Team'])                
                ->template($template_name)        
                ->setTo($mails)
                ->setEmailFormat('html')
                ->setViewVars(array(
                    'data' =>  $emailContent
                ))
                ->send();         
    }
}