<?php
namespace App\Controller\Admin;
use App\Controller\AppController;
use Exception;
use Cake\Auth\DefaultPasswordHasher;
use Cake\ORM\TableRegistry;
use Cake\Utility\Text;
use Cake\Utility\Security;
use Cake\Routing\RouteBuilder;
use Cake\Routing\Router;
/**
 * Admin Controller
 *
 *
 * @method \App\Model\Entity\Admin[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class AdminController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {
        $admin = $this->paginate($this->Admin);

        $this->set(compact('admin'));
    }

    /**
     * View method
     *
     * @param string|null $id Admin id.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $admin = $this->Admin->get($id, [
            'contain' => [],
        ]);

        $this->set('admin', $admin);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $admin = $this->Admin->newEntity();
        if ($this->request->is('post')) {
            $admin = $this->Admin->patchEntity($admin, $this->request->getData());
            if ($this->Admin->save($admin)) {
                $this->Flash->success(__('The admin has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The admin could not be saved. Please, try again.'));
        }
        $this->set(compact('admin'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Admin id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $admin = $this->Admin->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $admin = $this->Admin->patchEntity($admin, $this->request->getData());
            if ($this->Admin->save($admin)) {
                $this->Flash->success(__('The admin has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The admin could not be saved. Please, try again.'));
        }
        $this->set(compact('admin'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Admin id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $admin = $this->Admin->get($id);
        if ($this->Admin->delete($admin)) {
            $this->Flash->success(__('The admin has been deleted.'));
        } else {
            $this->Flash->error(__('The admin could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }


     public function login()
    {
        $this->loadModel('Users');
        try { 
            if ($this->request->is('post')) {
                $requestData = $this->request->getData();
                // pr($requestData);
                // die;
                $user = $this->Users->getUser(['email' => $requestData['email']]);
                // pr($user);
                // die;
                if (!empty($user)) 
                {
                    $hasher = new DefaultPasswordHasher(); // Load PaswordHasher
                    if ($hasher->check($requestData['password'],$user['password'])) 
                    {
                        if ($user['status']!= ACTIVE) 
                        { //check for active status
                            $this->Flash->error('Your account is still inactive.Please activate it.');
                            return $this->redirect(['action'=>'login']);  
                        } else {
                            $this->Auth->setUser($user);                                        
                            return $this->redirect(['action'=>'dashboard']);  
                        }
                    } else{
                        $this->Flash->error('Your password is incorrect.');
                    }                            
                } else {
                    $this->Flash->error('Your email or password is incorrect.');
                } 
            }        
        } catch (Exception $e) {
            $message = $e->getMessage();
            $this->Flash->error($message);
        }
    }
    public function logout()
    {
        session_destroy();
        $this->Flash->success('You are now logged out.');
        return $this->redirect($this->Auth->logout());
    }

    
   public function dashboard(){
         $this->viewBuilder()->layout('dashboard');
    }
}
