<?php
namespace App\Controller\Admin;

use App\Controller\AppController;

class CategoriesController extends AppController
{
    public function initialize()
    {
        parent::initialize();
        $this->loadModel('Categories');
    }
    public function add()
    {
        $data=$this->request->getData();
        $category = $this->Categories->newEntity();
        if ($this->request->is('post')) {
            $category = $this->Categories->patchEntity($category, $data);
            if ($this->Categories->save($category)) {
        // pr($category);
        // die;
                $this->Flash->success(__('The category has been saved.'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The category could not be saved. Please, try again.'));
            }
        }
        $this->set(compact('category'));
        $this->set('_serialize', ['category']);
    }

    public function index(){
        $this->loadModel('Categories');
        $categories = $this->Categories->categoryList();

        $this->viewBuilder()->layout('categoriesDashboard');
        $this->set(compact('categories'));
    }

    public function view()
    {
        $categories = $this->Categories->find('all', [
            'order' => [
                'Categories.sort' => 'ASC',
                'Categories.name' => 'ASC',
            ]
        ]);
        $this->set(compact('categories'));

        $category = $this->Categories->find('all')->first();
        if(empty($category)) {
            return $this->redirect(['action' => 'index']);
        }
        $this->set(compact('category'));
    }
    public function dashboard(){
        $this->viewBuilder()->layout('dashboard');
    }

}