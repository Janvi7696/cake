<?php
namespace App\Controller\Admin;
use App\Controller\AppController;

class ProductsController extends AppController
{
    public function initialize()
    {
        parent::initialize();
        $this->loadModel('Products');
    }
    public function add()
    {
        if ($this->request->is('post')) {
            $data=$this->request->getData();
             if($_FILES["fileToUpload"]["tmp_name"]){
                $target_dir = WWW_ROOT.'/uploads/';
                $image = basename($_FILES["fileToUpload"]["name"]);
                $image = str_replace(' ', '_', $image);
                $image = time() . $image;
                $target_file = $target_dir . $image;
                $uploadOk = 1;
                $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
                
                $allowed_image_extension = array(
                    "png",
                    "jpg",
                    "jpeg",
                    "doc",
                    "pdf"
                );
            if (! file_exists($_FILES["fileToUpload"]["tmp_name"])) {
                $response = array(
                    "type" => "error",
                    "message" => "Choose image file to upload."
                );
            }    // Validate file input to check if is with valid extension
            else if (! in_array($imageFileType, $allowed_image_extension)) {
                $response = array(
                    "type" => "error",
                    "message" => "Upload valiid images. Only PNG, JPEG, doc and pdf files are allowed."
                );
                echo $result;
            }    // Validate image file size
            else if (($_FILES["fileToUpload"]["size"] > 5000000)) {
                $response = array(
                    "type" => "error",
                    "message" => "Image size exceeds 5MB"
                );
            }
            // Check if image file is a actual image or fake image

                } else {
                   // $this->Flash->error(__('File not found'));
                
                $product = $this->Products->newEntity();
                $product = $this->Products->patchEntity($product, $data);
                if ($this->Products->save($product)) {
                    $this->Flash->success(__('The category has been saved.'));
                    return $this->redirect(['action' => 'index']);
                } else {
                    $this->Flash->error(__('The category could not be saved. Please, try again.'));
                }
            }
            $this->set(compact('product'));
            $this->set('_serialize', ['product']);
        }
    }
    
    public function index(){
        $this->loadModel('Products');
        $product = $this->Products->productList();

        $this->viewBuilder()->layout('productsDashboard');
        $this->set(compact('product'));
    }

    public function view()
    {
        $product = $this->Products->find('all', [
            'order' => [
                'Products.sort' => 'ASC',
                'Products.name' => 'ASC',
            ]
        ]);
        $this->set(compact('product'));

        $product = $this->Products->find('all')->first();
        if(empty($product)) {
            return $this->redirect(['action' => 'index']);
        }
        $this->set(compact('product'));
    }
    public function dashboard(){
        $this->viewBuilder()->layout('dashboard');
    }
}