<?php
namespace App\Controller;
use App\Controller\AppController;
use Exception;
use Cake\Auth\DefaultPasswordHasher;
use Cake\ORM\TableRegistry;
use Cake\Utility\Text;
use Cake\Utility\Security;
use Cake\Routing\RouteBuilder;
use Cake\Routing\Router;


class UsersController extends AppController
{
    public function initialize(){
        parent::initialize();
        $this->loadModel('Users');
        $this->Auth->allow('register');
        // $this->loadComponent('Common');
    }

    public function index()
    {
        $this->autoRender = false;
    }

    public function login()
    {
        try { 
            if ($this->request->is('post')) {
                $requestData = $this->request->getData();
                // pr($requestData);
                // die;
                $user = $this->Users->getUser(['email' => $requestData['email']]);
                // pr($user);
                // die;
                if (!empty($user)) 
                {
                    $hasher = new DefaultPasswordHasher(); // Load PaswordHasher
                    if ($hasher->check($requestData['password'],$user['password'])) 
                    {
                        if ($user['status']!= ACTIVE) 
                        { //check for active status
                            $this->Flash->error('Your account is still inactive.Please activate it.');
                            return $this->redirect(['action'=>'login']);  
                        } else {
                            $this->Auth->setUser($user);                                        
                            return $this->redirect(['action'=>'dashboard']);  
                        }
                    } else{
                        $this->Flash->error('Your password is incorrect.');
                    }                            
                } else {
                    $this->Flash->error('Your email or password is incorrect.');
                } 
            }        
        } catch (Exception $e) {
            $message = $e->getMessage();
            $this->Flash->error($message);
        }
    }

    public function forgotPassword()
    {
        if ($this->request->is('post')) 
        {
            $data = $this->request->getData();
            if($data['email']!='')
            {
                $user = $this->Users->getUserDetails(['email' => $data['email']]);
                 if (!empty($user))
                 {
                // pr($user);
                //      die;
                     $password = sha1(Text::uuid());

                     $password_token = Security::hash($password, 'sha256', true);

                     $hashval = sha1($user->username );

                     $user->password_reset_token = $password_token;
                     $user->hashval = $hashval;

                     $reset_token_link = Router::url(['controller' =>  'Users', 'action' => 'resetPassword'], TRUE) . '/' . $password_token . '#'. $hashval;
                     $emaildata = [$user->email, $reset_token_link];

                     $name = $user['first_name'].' '.$user['last_name'];

                     $mails = $user->email;
                     if($user->email!="") {
                        $emailContent = array(
                            'subject' => 'Welcome to the Website',
                            'name' => ucwords($name),
                            'emailData' => $emaildata
                        );
                        $template_name = 'forgotEtemplate';
                        $this->Common->sendEmail($mails,$emailContent,$template_name );

                        $this->Users->save($user);
                        $this->Flash->success('Please click on password reset link, sent in your email address to reset password.');
                        $this->redirect(['action' =>'forgotPassword']);
                    }
                    else
                    {
                        $this->Flash->error('Sorry! Email address is not available here.');
                    }
                }else{
                    $this->Flash->error("Email does'nt exist");
                }
            }else{
                $this->Flash->error("Email can't be empty");
                $this->redirect(['controller'=>'Users','action'=>'forgot-password']);
            }
        }
    }
    
    public function logout()
    {
        session_destroy();
        $this->Flash->success('You are now logged out.');
        return $this->redirect($this->Auth->logout());
    }

    public function dashboard(){
         $this->viewBuilder()->layout('dashboard');
    }
}
