<?php
namespace App\Model\Table;
use Cake\ORM\Table;
use Cake\Validation\Validator;
use Cake\ORM\TableRegistry;

class CategoriesTable extends Table 
{   
	 public function categoryList($condition = [])
    {
        $result = $this->find();
        if(!empty($condition)){
            $result = $result->where($condition);
        }
        return $result->order(['id' => 'DESC'])->limit(20)->page(1)->hydrate(false)->toArray();
    }
}