<?php
namespace App\Model\Table;
use Cake\ORM\Table;
// In a controller or table method.
use Cake\ORM\TableRegistry;
use Cake\Auth\DefaultPasswordHasher;
use Cake\Validation\Validator;

class UsersTable extends Table 
{
	public function getUser($data  = array())
    {
		return $this->find()
         ->where($data)
         ->first();        
    }
}